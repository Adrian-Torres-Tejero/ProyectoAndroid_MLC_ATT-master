# Android-AppContactosATML
![Logo de Kotlin](https://imgs.search.brave.com/XRSxCMDs4fxddxGP9v_sNWIEhmVLOjoz0TrRBMewcKk/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMuc2Vla2xvZ28u/Y29tL2xvZ28tcG5n/LzMyLzIva290bGlu/LWxvZ28tcG5nX3Nl/ZWtsb2dvLTMyMzQz/MC5wbmc)
## Descripción
### Practica final de Android en Kotlin. Realizado por: Miguel López y Adrián Torres.
### Fase 1.
Agenda de contactos. Esta aplicacion consiste en una agenda de contactos que comineza en la pantalla "Login" en donde introducimos nuestro nombre y contraseña para se redirigidos mediante el NavHostController a la pantalla "Home". Desde esta pantalla recogemos los contactos de la pantalla "UsuariosContactos" y los pintamos en el home a su vez podemos entrar en los detalles del contacto mediante el icono o el FloatingButtom los cuales nos redirigiran a la pantalla de "DetallesContactos"
### Fase2.
Se han completado los requerimientos de la fase 2: MainviewModel recoje los contactos desde la API y las pinta con ContactListScreen
